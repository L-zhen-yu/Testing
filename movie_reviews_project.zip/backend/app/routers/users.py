"""
User-related routes for the Movie Reviews API.

Provides endpoints to retrieve user information and manage user-specific
data such as favorites.  Some endpoints require authentication and
authorization via JWT tokens and roles.
"""

from fastapi import APIRouter, Depends, HTTPException, status

from .. import schemas
from ..auth import get_current_user, require_role
from ..repositories.user_repository import UserRepository


router = APIRouter()


@router.get("/me", response_model=schemas.UserOut)
def read_users_me(current_user: schemas.UserOut = Depends(get_current_user)) -> schemas.UserOut:
    """Return information about the currently authenticated user."""
    return current_user


@router.get("/", response_model=list[schemas.UserOut])
def list_users(current_user: schemas.UserOut = Depends(require_role("admin")), user_repo: UserRepository = Depends()) -> list[schemas.UserOut]:
    """List all users (admin only)."""
    return user_repo.list_users()


@router.post("/me/favorites/{movie_id}", status_code=status.HTTP_204_NO_CONTENT)
def add_favorite_movie(movie_id: str, current_user: schemas.UserOut = Depends(get_current_user), user_repo: UserRepository = Depends()) -> None:
    """Add a movie to the current user's favorites."""
    user_repo.add_favorite(current_user.id, movie_id)


@router.delete("/me/favorites/{movie_id}", status_code=status.HTTP_204_NO_CONTENT)
def remove_favorite_movie(movie_id: str, current_user: schemas.UserOut = Depends(get_current_user), user_repo: UserRepository = Depends()) -> None:
    """Remove a movie from the current user's favorites."""
    user_repo.remove_favorite(current_user.id, movie_id)