"""
Pydantic schemas (serializers) for the Movie Reviews API.

These models define the structure of data exchanged between the client and
server.  They are separate from the data persistence layer (which uses
simple Python dictionaries and JSON files) and provide validation and
documentation for FastAPI.
"""

from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field


# Authentication schemas
class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class TokenData(BaseModel):
    username: Optional[str] = None


class UserBase(BaseModel):
    username: str
    full_name: str


class UserCreate(UserBase):
    password: str


class UserLogin(BaseModel):
    username: str
    password: str


class UserOut(UserBase):
    id: str
    role: str
    penalties: List[str] = []
    favorites: List[str] = []


# Movie schemas
class MovieBase(BaseModel):
    title: str
    year: Optional[str] = None
    genre: Optional[str] = None
    director: Optional[str] = None
    actors: Optional[str] = None
    plot: Optional[str] = None
    poster: Optional[str] = None
    omdb_rating: Optional[str] = None


class MovieCreate(BaseModel):
    # either provide full metadata or just a title/imdb_id to fetch from OMDb
    title: str
    imdb_id: Optional[str] = None


class MovieOut(MovieBase):
    id: str
    average_rating: Optional[float] = None
    review_count: int = 0


# Review schemas
class ReviewBase(BaseModel):
    movie_id: str
    rating: int = Field(..., ge=1, le=5)
    content: str
    parent_id: Optional[str] = None


class ReviewCreate(ReviewBase):
    pass


class ReviewOut(ReviewBase):
    id: str
    user_id: str
    username: str
    created_at: datetime
    likes: int = 0
    dislikes: int = 0
    replies: List['ReviewOut'] = []  # type: ignore  # forward reference

    class Config:
        orm_mode = True


class Penalty(BaseModel):
    id: str
    user_id: str
    reason: str
    date: datetime
    active: bool = True


# Update forward references for ReviewOut.replies
ReviewOut.update_forward_refs()