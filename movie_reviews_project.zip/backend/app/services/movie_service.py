"""
Service layer for movies, encapsulating business logic.

The MovieService composes the MovieRepository, ReviewRepository, and
optionally the OMDbService to provide higher-level operations
on movies, including computing average ratings and handling search
and filter operations.
"""

from typing import Dict, List, Optional

from ..repositories.movie_repository import MovieRepository
from ..repositories.review_repository import ReviewRepository
from ..services.omdb_service import OMDbService


class MovieService:
    def __init__(self, movie_repo: MovieRepository, review_repo: ReviewRepository, omdb_service: Optional[OMDbService] = None) -> None:
        self.movie_repo = movie_repo
        self.review_repo = review_repo
        self.omdb_service = omdb_service

    def _compute_rating(self, movie_id: str) -> (Optional[float], int):
        reviews = self.review_repo.list_reviews_by_movie(movie_id)
        if not reviews:
            return None, 0
        total = sum(r["rating"] for r in reviews)
        return total / len(reviews), len(reviews)

    def list_movies(
        self,
        search: Optional[str] = None,
        genre: Optional[str] = None,
        year: Optional[str] = None,
        sort_by: Optional[str] = None,
    ) -> List[Dict]:
        movies = self.movie_repo.list_movies()
        # search
        if search:
            search_lower = search.lower()
            movies = [m for m in movies if search_lower in m.get("title", "").lower()]
        # filter
        if genre:
            movies = [m for m in movies if genre.lower() in (m.get("genre", "").lower())]
        if year:
            movies = [m for m in movies if m.get("year") == year]
        # compute ratings for sorting
        enriched = []
        for m in movies:
            avg, count = self._compute_rating(m["id"])
            enriched.append({**m, "average_rating": avg, "review_count": count})
        if sort_by == "rating":
            enriched.sort(key=lambda x: (x["average_rating"] or 0), reverse=True)
        elif sort_by == "year":
            enriched.sort(key=lambda x: x.get("year", ""), reverse=True)
        return enriched

    def get_movie(self, movie_id: str) -> Optional[Dict]:
        movie = self.movie_repo.get_movie(movie_id)
        if not movie:
            return None
        avg, count = self._compute_rating(movie_id)
        return {**movie, "average_rating": avg, "review_count": count}

    async def create_movie(self, title: str, imdb_id: Optional[str] = None) -> Dict:
        # If OMDb service available, fetch details
        data: Dict[str, str] = {"title": title}
        if self.omdb_service:
            info = None
            if imdb_id:
                info = await self.omdb_service.fetch_by_imdb_id(imdb_id)
            if not info:
                info = await self.omdb_service.fetch_by_title(title)
            if info:
                data.update(
                    {
                        "title": info.get("Title"),
                        "year": info.get("Year"),
                        "genre": info.get("Genre"),
                        "director": info.get("Director"),
                        "actors": info.get("Actors"),
                        "plot": info.get("Plot"),
                        "poster": info.get("Poster"),
                        "omdb_rating": info.get("imdbRating"),
                    }
                )
        return self.movie_repo.create_movie(data)

    def update_movie(self, movie_id: str, updated_data: Dict) -> Optional[Dict]:
        return self.movie_repo.update_movie(movie_id, updated_data)

    def delete_movie(self, movie_id: str) -> bool:
        return self.movie_repo.delete_movie(movie_id)