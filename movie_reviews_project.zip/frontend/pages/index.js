import { useEffect, useState } from 'react';
import Link from 'next/link';
import { fetchMovies } from '@/lib/api';

export default function Home() {
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const data = await fetchMovies();
        setMovies(data);
      } catch (e) {
        console.error('Failed to fetch movies', e);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  return (
    <div style={{ maxWidth: '800px', margin: '0 auto', padding: '1rem' }}>
      <h1>Movie Reviews</h1>
      {loading ? <p>Loading...</p> : (
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {movies.map(movie => (
            <li key={movie.id} style={{ marginBottom: '1rem', padding: '1rem', background: '#fff', borderRadius: '8px' }}>
              <Link href={`/movies/${movie.id}`}>
                <a style={{ fontSize: '1.2rem', fontWeight: 'bold' }}>{movie.title} ({movie.year})</a>
              </Link>
              <p>Average rating: {movie.average_rating ? movie.average_rating.toFixed(1) : 'N/A'} ({movie.review_count} reviews)</p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}