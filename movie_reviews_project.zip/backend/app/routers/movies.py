"""
Movie-related routes for the Movie Reviews API.

Provides endpoints to list, create, update, and delete movies.  The
MovieService is used to apply business logic such as computing
average ratings and integrating with the OMDb API when creating
movies.  Admin-only endpoints are protected via role-based
dependencies.
"""

from fastapi import APIRouter, Depends, HTTPException, Query, status

from .. import schemas
from ..auth import get_current_user, require_role
from ..repositories.movie_repository import MovieRepository
from ..repositories.review_repository import ReviewRepository
from ..services.movie_service import MovieService
from ..services.omdb_service import OMDbService


router = APIRouter()


def get_movie_service() -> MovieService:
    movie_repo = MovieRepository()
    review_repo = ReviewRepository()
    # Try to instantiate OMDb service, but don't fail if key missing
    try:
        omdb_service = OMDbService()
    except Exception:
        omdb_service = None
    return MovieService(movie_repo, review_repo, omdb_service)


@router.get("/", response_model=list[schemas.MovieOut])
def list_movies(
    search: str | None = Query(default=None, description="Search keyword for movie titles"),
    genre: str | None = Query(default=None, description="Filter by genre"),
    year: str | None = Query(default=None, description="Filter by year"),
    sort_by: str | None = Query(default=None, description="Sort by 'rating' or 'year'"),
    service: MovieService = Depends(get_movie_service),
) -> list[schemas.MovieOut]:
    """List movies with optional search, filter, and sorting."""
    movies = service.list_movies(search=search, genre=genre, year=year, sort_by=sort_by)
    return [schemas.MovieOut(**m) for m in movies]


@router.get("/{movie_id}", response_model=schemas.MovieOut)
def get_movie(movie_id: str, service: MovieService = Depends(get_movie_service)) -> schemas.MovieOut:
    """Retrieve a single movie by ID."""
    movie = service.get_movie(movie_id)
    if not movie:
        raise HTTPException(status_code=404, detail="Movie not found")
    return schemas.MovieOut(**movie)


@router.post("/", response_model=schemas.MovieOut, status_code=status.HTTP_201_CREATED)
async def create_movie(
    movie: schemas.MovieCreate,
    current_user: schemas.UserOut = Depends(require_role("admin")),
    service: MovieService = Depends(get_movie_service),
) -> schemas.MovieOut:
    """Create a new movie (admin only)."""
    created = await service.create_movie(title=movie.title, imdb_id=movie.imdb_id)
    return schemas.MovieOut(**created)


@router.put("/{movie_id}", response_model=schemas.MovieOut)
def update_movie(
    movie_id: str,
    updated: dict,
    current_user: schemas.UserOut = Depends(require_role("admin")),
    service: MovieService = Depends(get_movie_service),
) -> schemas.MovieOut:
    """Update an existing movie (admin only)."""
    m = service.update_movie(movie_id, updated)
    if not m:
        raise HTTPException(status_code=404, detail="Movie not found")
    return schemas.MovieOut(**m)


@router.delete("/{movie_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_movie(
    movie_id: str,
    current_user: schemas.UserOut = Depends(require_role("admin")),
    service: MovieService = Depends(get_movie_service),
) -> None:
    """Delete a movie (admin only)."""
    if not service.delete_movie(movie_id):
        raise HTTPException(status_code=404, detail="Movie not found")