"""
Backend application package initialization.

This file marks the ``app`` directory as a package and can be used to
expose shared imports or metadata.
"""