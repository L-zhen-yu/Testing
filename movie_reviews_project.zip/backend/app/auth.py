"""
Authentication and authorization utilities for the Movie Reviews API.

This module provides functions to hash passwords, verify passwords,
generate and decode JWT tokens, and FastAPI dependencies to obtain the
current authenticated user and enforce role-based access control.

For simplicity the secret key is stored in a constant here.  In a real
deployment you would load this from an environment variable or secret
management service.
"""

from datetime import datetime, timedelta
from typing import Optional

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from jose import JWTError, jwt
from passlib.context import CryptContext

from . import schemas
from .repositories.user_repository import UserRepository

# Secret key and algorithm for JWT
SECRET_KEY = "CHANGE_ME_PLEASE_THIS_IS_A_SECRET"  # replace in production
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24  # 1 day

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/token")


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)


def get_password_hash(password: str) -> str:
    return pwd_context.hash(password)


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt


async def get_current_user(
    token: str = Depends(oauth2_scheme), user_repo: UserRepository = Depends()
) -> schemas.UserOut:
    """Decode JWT token and return the current user."""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")  # subject
        if username is None:
            raise credentials_exception
        token_data = schemas.TokenData(username=username)
    except JWTError:
        raise credentials_exception
    user = user_repo.get_user_by_username(token_data.username)
    if user is None:
        raise credentials_exception
    return user


def require_role(required_role: str):
    """
    Dependency generator that ensures the current user has the specified role.

    Usage:

        @router.get(...)
        async def secure_endpoint(current_user: UserOut = Depends(require_role("admin"))):
            ...
    """

    async def role_dependency(
        current_user: schemas.UserOut = Depends(get_current_user),
    ) -> schemas.UserOut:
        if current_user.role != required_role:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Insufficient permissions",
            )
        return current_user

    return role_dependency