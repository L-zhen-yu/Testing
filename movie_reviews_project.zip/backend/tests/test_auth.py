"""
Tests for authentication endpoints.
"""

import json
from fastapi.testclient import TestClient

from app.main import app


client = TestClient(app)


def test_register_and_login(tmp_path, monkeypatch):
    # Patch data directory to temporary path
    from app.repositories import base
    base.DATA_DIR = tmp_path
    # ensure data files exist
    (tmp_path / "users.json").write_text("[]")
    (tmp_path / "movies.json").write_text("[]")
    (tmp_path / "reviews.json").write_text("[]")

    # Register user
    response = client.post(
        "/auth/register",
        json={"username": "alice", "full_name": "Alice", "password": "password"},
    )
    assert response.status_code == 201
    data = response.json()
    assert data["username"] == "alice"
    assert "id" in data

    # Login user
    response = client.post(
        "/auth/token",
        data={"username": "alice", "password": "password"},
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    assert response.status_code == 200
    token_data = response.json()
    assert "access_token" in token_data