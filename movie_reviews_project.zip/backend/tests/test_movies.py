"""
Tests for movie endpoints.
"""

from fastapi.testclient import TestClient

from app.main import app


client = TestClient(app)


def test_list_movies_empty(tmp_path, monkeypatch):
    # Patch data directory to temporary path
    from app.repositories import base
    base.DATA_DIR = tmp_path
    (tmp_path / "users.json").write_text("[]")
    (tmp_path / "movies.json").write_text("[]")
    (tmp_path / "reviews.json").write_text("[]")

    response = client.get("/movies")
    assert response.status_code == 200
    assert response.json() == []