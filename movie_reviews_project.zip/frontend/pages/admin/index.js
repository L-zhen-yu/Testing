import { useEffect, useState } from 'react';
import { fetchUsers, applyPenalty } from '@/lib/api';
import { setAuthToken } from '@/lib/api';

export default function AdminPage() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [penaltyReason, setPenaltyReason] = useState('');
  const [selectedUser, setSelectedUser] = useState(null);

  useEffect(() => {
    const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null;
    if (token) setAuthToken(token);
    async function load() {
      try {
        const data = await fetchUsers();
        setUsers(data);
      } catch (e) {
        setError(e.response?.data?.detail || 'Failed to load users');
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  async function handleApplyPenalty() {
    if (!selectedUser || !penaltyReason) return;
    try {
      await applyPenalty(selectedUser.id, penaltyReason);
      // refresh users
      const data = await fetchUsers();
      setUsers(data);
      setPenaltyReason('');
    } catch (e) {
      alert(e.response?.data?.detail || 'Failed to apply penalty');
    }
  }

  return (
    <div style={{ padding: '1rem' }}>
      <h1>Admin Panel</h1>
      {loading ? <p>Loading...</p> : error ? <p style={{ color: 'red' }}>{error}</p> : (
        <div>
          <table border="1" cellPadding="8">
            <thead>
              <tr><th>ID</th><th>Username</th><th>Role</th><th>Penalties</th></tr>
            </thead>
            <tbody>
              {users.map(u => (
                <tr key={u.id} onClick={() => setSelectedUser(u)} style={{ background: selectedUser?.id === u.id ? '#eef' : 'transparent', cursor: 'pointer' }}>
                  <td>{u.id}</td>
                  <td>{u.username}</td>
                  <td>{u.role}</td>
                  <td>{u.penalties.join(', ') || 'None'}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {selectedUser && (
            <div style={{ marginTop: '1rem' }}>
              <h2>Apply Penalty to {selectedUser.username}</h2>
              <input value={penaltyReason} onChange={e => setPenaltyReason(e.target.value)} placeholder="Reason" />
              <button onClick={handleApplyPenalty}>Apply</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}