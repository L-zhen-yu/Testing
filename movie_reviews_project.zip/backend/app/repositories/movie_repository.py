"""
Repository for movie data stored in a JSON file.

Movies are stored as dictionaries with keys defined in the MovieOut schema.
They do not contain computed fields like average_rating or review_count;
those are calculated in services using the ReviewRepository.
"""

import uuid
from typing import List, Optional

from ..schemas import MovieCreate, MovieOut
from .base import JSONRepository


class MovieRepository(JSONRepository):
    file_name = "movies.json"

    def list_movies(self) -> List[dict]:
        return self._read()

    def get_movie(self, movie_id: str) -> Optional[dict]:
        return self.find_by_id(movie_id)

    def create_movie(self, movie_data: dict) -> dict:
        movies = self._read()
        new_movie = {"id": str(uuid.uuid4()), **movie_data}
        movies.append(new_movie)
        self._write(movies)
        return new_movie

    def update_movie(self, movie_id: str, updated_data: dict) -> Optional[dict]:
        movies = self._read()
        for m in movies:
            if m["id"] == movie_id:
                m.update(updated_data)
                self._write(movies)
                return m
        return None

    def delete_movie(self, movie_id: str) -> bool:
        return self.delete_by_id(movie_id)