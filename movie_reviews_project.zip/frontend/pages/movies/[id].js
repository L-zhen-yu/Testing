import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import { fetchMovie, fetchReviews, postReview, likeReview, dislikeReview } from '@/lib/api';
import { setAuthToken } from '@/lib/api';

export default function MovieDetail() {
  const router = useRouter();
  const { id } = router.query;
  const [movie, setMovie] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [rating, setRating] = useState(5);
  const [content, setContent] = useState('');
  const [error, setError] = useState(null);

  // On mount, set token from localStorage if exists
  useEffect(() => {
    const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null;
    if (token) setAuthToken(token);
  }, []);

  useEffect(() => {
    if (!id) return;
    async function load() {
      try {
        const m = await fetchMovie(id);
        setMovie(m);
        const r = await fetchReviews(id);
        setReviews(r);
      } catch (e) {
        console.error(e);
      }
    }
    load();
  }, [id]);

  async function handleSubmit(e) {
    e.preventDefault();
    try {
      const review = await postReview(id, rating, content);
      setReviews([review, ...reviews]);
      setContent('');
    } catch (e) {
      setError(e.response?.data?.detail || 'Failed to post review');
    }
  }

  function renderReviews(list, indent = 0) {
    return list.map(r => (
      <div key={r.id} style={{ marginLeft: indent * 20, borderLeft: indent ? '1px solid #ccc' : 'none', paddingLeft: '8px', marginTop: '8px' }}>
        <p><strong>{r.username}</strong> rated {r.rating}/5</p>
        <p>{r.content}</p>
        <button onClick={async () => {
          const updated = await likeReview(r.id);
          setReviews(prev => prev.map(item => item.id === updated.id ? updated : item));
        }}>Like ({r.likes})</button>
        <button onClick={async () => {
          const updated = await dislikeReview(r.id);
          setReviews(prev => prev.map(item => item.id === updated.id ? updated : item));
        }}>Dislike ({r.dislikes})</button>
        {r.replies && renderReviews(r.replies, indent + 1)}
      </div>
    ));
  }

  if (!movie) return <p>Loading...</p>;

  return (
    <div style={{ maxWidth: '800px', margin: '0 auto', padding: '1rem' }}>
      <h1>{movie.title} ({movie.year})</h1>
      {movie.genre && <p><strong>Genre:</strong> {movie.genre}</p>}
      {movie.director && <p><strong>Director:</strong> {movie.director}</p>}
      {movie.actors && <p><strong>Actors:</strong> {movie.actors}</p>}
      {movie.plot && <p><strong>Plot:</strong> {movie.plot}</p>}
      {movie.average_rating && <p><strong>Average Rating:</strong> {movie.average_rating.toFixed(1)} ({movie.review_count} reviews)</p>}

      <hr />
      <h2>Reviews</h2>
      {reviews.length === 0 && <p>No reviews yet.</p>}
      <div>
        {renderReviews(reviews)}
      </div>
      <hr />
      <h3>Leave a review</h3>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <form onSubmit={handleSubmit}>
        <label>Rating:
          <select value={rating} onChange={e => setRating(parseInt(e.target.value))} style={{ marginLeft: '8px' }}>
            {[1,2,3,4,5].map(n => <option key={n} value={n}>{n}</option>)}
          </select>
        </label>
        <br />
        <textarea value={content} onChange={e => setContent(e.target.value)} rows={4} cols={50} placeholder="Write your review..." style={{ display: 'block', marginTop: '8px' }} />
        <button type="submit">Submit Review</button>
      </form>
    </div>
  );
}