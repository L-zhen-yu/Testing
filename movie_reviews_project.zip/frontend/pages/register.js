import { useState } from 'react';
import { useRouter } from 'next/router';
import { register, setAuthToken, login } from '@/lib/api';

export default function RegisterPage() {
  const router = useRouter();
  const [username, setUsername] = useState('');
  const [fullName, setFullName] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null);

  async function handleSubmit(e) {
    e.preventDefault();
    setError(null);
    try {
      await register(username, fullName, password);
      // auto-login after register
      const data = await login(username, password);
      localStorage.setItem('token', data.access_token);
      setAuthToken(data.access_token);
      router.push('/');
    } catch (e) {
      setError(e.response?.data?.detail || 'Registration failed');
    }
  }

  return (
    <div style={{ maxWidth: '400px', margin: '0 auto', padding: '2rem' }}>
      <h1>Register</h1>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <form onSubmit={handleSubmit}>
        <div>
          <label>Username
            <input type="text" value={username} onChange={e => setUsername(e.target.value)} required />
          </label>
        </div>
        <div>
          <label>Full Name
            <input type="text" value={fullName} onChange={e => setFullName(e.target.value)} required />
          </label>
        </div>
        <div>
          <label>Password
            <input type="password" value={password} onChange={e => setPassword(e.target.value)} required />
          </label>
        </div>
        <button type="submit">Register</button>
      </form>
      <p>Already have an account? <a href="/login">Login</a></p>
    </div>
  );
}