"""
Service for interacting with the OMDb API (http://www.omdbapi.com/).

The service can fetch movie information by title or IMDb ID using an
API key.  To use this service you must set the ``OMDB_API_KEY``
environment variable or provide a key when constructing the service.
"""

import os
from typing import Any, Dict, Optional

import httpx


class OMDbService:
    BASE_URL = "http://www.omdbapi.com/"

    def __init__(self, api_key: Optional[str] = None) -> None:
        self.api_key = api_key or os.getenv("OMDB_API_KEY")
        if not self.api_key:
            raise RuntimeError(
                "OMDb API key is not set. Set OMDB_API_KEY environment variable."
            )

    async def fetch_by_title(self, title: str) -> Optional[Dict[str, Any]]:
        params = {"apikey": self.api_key, "t": title}
        async with httpx.AsyncClient() as client:
            resp = await client.get(self.BASE_URL, params=params)
            data = resp.json()
            if data.get("Response") == "True":
                return data
        return None

    async def fetch_by_imdb_id(self, imdb_id: str) -> Optional[Dict[str, Any]]:
        params = {"apikey": self.api_key, "i": imdb_id}
        async with httpx.AsyncClient() as client:
            resp = await client.get(self.BASE_URL, params=params)
            data = resp.json()
            if data.get("Response") == "True":
                return data
        return None