import { useState } from 'react';
import { useRouter } from 'next/router';
import { login, setAuthToken } from '@/lib/api';

export default function LoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null);

  async function handleSubmit(e) {
    e.preventDefault();
    setError(null);
    try {
      const data = await login(username, password);
      localStorage.setItem('token', data.access_token);
      setAuthToken(data.access_token);
      router.push('/');
    } catch (e) {
      setError(e.response?.data?.detail || 'Login failed');
    }
  }

  return (
    <div style={{ maxWidth: '400px', margin: '0 auto', padding: '2rem' }}>
      <h1>Login</h1>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <form onSubmit={handleSubmit}>
        <div>
          <label>Username
            <input type="text" value={username} onChange={e => setUsername(e.target.value)} required />
          </label>
        </div>
        <div>
          <label>Password
            <input type="password" value={password} onChange={e => setPassword(e.target.value)} required />
          </label>
        </div>
        <button type="submit">Login</button>
      </form>
      <p>Don't have an account? <a href="/register">Register</a></p>
    </div>
  );
}