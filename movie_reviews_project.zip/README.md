# Movie Reviews System

This repository contains a full‑stack multiuser system for managing movie reviews, built as part of an academic software engineering project.  The project demonstrates modern engineering practices, including a FastAPI backend, a Next.js frontend, JSON‑based storage, role‑based authentication, testing, CI via GitHub Actions, and containerization using Docker.

## Features

* **Backend** – Implemented with [FastAPI](https://fastapi.tiangolo.com/) in Python.  Data is persisted to JSON files under `backend/app/data` rather than using a traditional database.  The backend exposes a RESTful API with endpoints for user registration/login, movies (listing, searching, creating, updating, deleting), reviews (creating, updating, deleting, liking/disliking, nested replies), and admin functions (applying penalties).
* **Authentication** – Users register with a username, full name, and password.  Passwords are hashed with bcrypt and stored securely.  Login returns a JWT token used for authenticated requests.  Role‑based access control (admin vs regular user) is enforced via dependencies.
* **Frontend** – Built with [Next.js](https://nextjs.org/) and React.  Provides pages for browsing movies, viewing details, login and registration, posting reviews, and a simple admin panel for managing users and penalties.  It communicates with the backend via Axios and stores the JWT token in `localStorage`.
* **External Integration** – When creating movies, the backend optionally uses the [OMDb API](http://www.omdbapi.com/) to fetch metadata based on a title or IMDb ID.  To enable this integration, set the `OMDB_API_KEY` environment variable (see below).
* **Testing** – Backend unit tests are written with `pytest` and live in `backend/tests`.  A minimal test suite is provided and can be expanded.  Frontend tests and end‑to‑end tests can be added in `testing‑documents`.
* **CI/CD** – A GitHub Actions workflow (`.github/workflows/ci.yml`) automatically installs dependencies, runs backend tests, and builds the frontend on each push or pull request to the main branch.
* **Docker** – Both the backend and frontend can be containerized using the provided `Dockerfile`s.  A `docker‑compose.yml` file orchestrates running both services together for development or deployment.

## Getting Started

### Prerequisites

Ensure you have the following installed:

* [Python 3.11](https://www.python.org/) or newer
* [Node.js 18](https://nodejs.org/)
* [Docker](https://www.docker.com/) and [Docker Compose](https://docs.docker.com/compose/) (optional but recommended for running both services together)

### Running the Backend

Install dependencies and start the FastAPI server:

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

The server will run on `http://localhost:8000`.  Interactive API documentation is available at `http://localhost:8000/docs`.

### Running the Frontend

Install dependencies and start the Next.js development server:

```bash
cd frontend
npm install
npm run dev
```

The frontend will run on `http://localhost:3000`.  It expects the backend to be running on `http://localhost:8000` by default.  You can change this by setting the `NEXT_PUBLIC_API_URL` environment variable.

### Using Docker Compose

To run both services together in containers:

```bash
docker-compose up --build
```

This will build and start the backend on port 8000 and the frontend on port 3000.  Data is persisted to the `backend/app/data` directory on the host machine.

To enable the OMDb integration, set the `OMDB_API_KEY` environment variable when running Docker Compose, for example:

```bash
OMDB_API_KEY=your_key_here docker-compose up --build
```

### Testing

Run the backend unit tests with:

```bash
cd backend
pytest
```

A basic test suite is provided; feel free to add more tests to cover additional functionality.  Test reports and related documents can be stored in the `testing‑documents` folder.

### Project Structure

```
.
├── backend
│   ├── app
│   │   ├── data            # JSON files for persistence
│   │   ├── repositories    # Data access layer
│   │   ├── services        # Business logic
│   │   ├── routers         # FastAPI route definitions
│   │   ├── schemas.py      # Pydantic models
│   │   ├── auth.py         # Password hashing and JWT
│   │   └── main.py         # Application entry point
│   ├── tests               # Pytest test suite
│   ├── requirements.txt
│   └── Dockerfile
├── frontend
│   ├── pages              # Next.js pages
│   ├── lib                # API helper
│   ├── styles            # Global styles
│   ├── package.json
│   └── Dockerfile
├── docker-compose.yml
├── .github/workflows/ci.yml
├── testing‑documents
├── scrum‑documents
└── README.md
```

## Notes

* This project avoids using a traditional database.  JSON files are used for persistence, which simplifies setup but is not suitable for production workloads or concurrent writes.
* The admin features are intentionally minimal.  A real system would include more robust moderation tools, auditing, and configurable roles.
* OMDb API integration is optional.  If no API key is set, movies can still be created by manually specifying titles and additional metadata via the API.

## License

This project is provided as a learning example and does not specify a license.  Feel free to adapt it for educational purposes.