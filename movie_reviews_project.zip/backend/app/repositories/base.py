"""
Base classes and utilities for JSON file-based repositories.

Repositories provide an abstraction over the JSON storage, encapsulating
reading and writing of data to JSON files under the ``data`` directory.
Each repository deals with a specific entity type and exposes CRUD
operations.  In production you might replace this with a real database.
"""

import json
from pathlib import Path
from typing import Any, List, Optional


DATA_DIR = Path(__file__).resolve().parent.parent / "data"
DATA_DIR.mkdir(exist_ok=True)


class JSONRepository:
    """Generic repository for reading and writing JSON list data."""

    file_name: str

    def __init__(self):
        self.path = DATA_DIR / self.file_name
        if not self.path.exists():
            # Initialize with empty list
            with open(self.path, "w", encoding="utf-8") as f:
                json.dump([], f)

    def _read(self) -> List[dict]:
        with open(self.path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _write(self, data: List[dict]) -> None:
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def list_all(self) -> List[dict]:
        return self._read()

    def save_all(self, items: List[dict]) -> None:
        self._write(items)

    def find_by_id(self, item_id: str) -> Optional[dict]:
        items = self._read()
        for item in items:
            if item.get("id") == item_id:
                return item
        return None

    def delete_by_id(self, item_id: str) -> bool:
        items = self._read()
        new_items = [item for item in items if item.get("id") != item_id]
        if len(new_items) == len(items):
            return False
        self._write(new_items)
        return True