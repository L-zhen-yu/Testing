"""
Admin routes for the Movie Reviews API.

Only users with the "admin" role can access these endpoints.  They
allow managing users and applying penalties.
"""

from fastapi import APIRouter, Depends, HTTPException, status

from .. import schemas
from ..auth import require_role
from ..repositories.user_repository import UserRepository


router = APIRouter()


@router.post("/users/{user_id}/penalties", status_code=status.HTTP_204_NO_CONTENT)
def apply_penalty(
    user_id: str,
    reason: str,
    current_user: schemas.UserOut = Depends(require_role("admin")),
    user_repo: UserRepository = Depends(),
) -> None:
    """Apply a penalty to a user (admin only)."""
    if not user_repo.get_user_by_id(user_id):
        raise HTTPException(status_code=404, detail="User not found")
    user_repo.add_penalty(user_id, reason)


@router.get("/users/{user_id}", response_model=schemas.UserOut)
def get_user_details(
    user_id: str,
    current_user: schemas.UserOut = Depends(require_role("admin")),
    user_repo: UserRepository = Depends(),
) -> schemas.UserOut:
    """Get details of a specific user (admin only)."""
    user = user_repo.get_user_by_id(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user