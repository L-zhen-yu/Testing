"""
Main application entry point for the FastAPI backend.

This module configures the FastAPI instance, includes routers for different
functional areas (authentication, movies, reviews, users, and admin) and
creates the application object which can be used by ASGI servers like Uvicorn.

The backend stores its data in JSON files located under the ``data``
directory.  Repositories abstract file operations, services encapsulate
business logic, and routers define RESTful API endpoints.

Running this module directly will start a development server.  In
production the Docker container uses Uvicorn to run this app.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .routers import auth, movies, reviews, users, admin


def create_app() -> FastAPI:
    """Create and configure the FastAPI application."""
    app = FastAPI(title="Movie Reviews API", version="1.0.0")

    # Allow frontend origins during development.  In production restrict this.
    origins = [
        "http://localhost",
        "http://localhost:3000",
        "*",  # adjust as needed
    ]
    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Include API routers
    app.include_router(auth.router, prefix="/auth", tags=["auth"])
    app.include_router(users.router, prefix="/users", tags=["users"])
    app.include_router(movies.router, prefix="/movies", tags=["movies"])
    app.include_router(reviews.router, prefix="/reviews", tags=["reviews"])
    app.include_router(admin.router, prefix="/admin", tags=["admin"])

    return app


app = create_app()


@app.get("/")
async def root():
    """Simple health check endpoint."""
    return {"message": "Movie Reviews API running"}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)