"""
Review-related routes for the Movie Reviews API.

Allows users to create, view, update, delete, and interact with movie
reviews.  Reviews are stored in a flat list in a JSON file; helper
functions convert them into nested trees when returned to clients.
"""

from collections import defaultdict
from typing import Dict, List

from fastapi import APIRouter, Depends, HTTPException, status

from .. import schemas
from ..auth import get_current_user, require_role
from ..repositories.review_repository import ReviewRepository
from ..repositories.movie_repository import MovieRepository


router = APIRouter()


def build_review_tree(reviews: List[dict]) -> List[schemas.ReviewOut]:
    """
    Build a tree of replies from a flat list of reviews.
    Returns a list of root reviews (those without parent_id) with nested
    replies populated in the ``replies`` attribute.
    """
    by_id: Dict[str, schemas.ReviewOut] = {}
    children: Dict[str, List[schemas.ReviewOut]] = defaultdict(list)
    for r in reviews:
        ro = schemas.ReviewOut(
            id=r["id"],
            movie_id=r["movie_id"],
            user_id=r["user_id"],
            username=r["username"],
            rating=r["rating"],
            content=r["content"],
            parent_id=r.get("parent_id"),
            created_at=r.get("created_at"),
            likes=r.get("likes", 0),
            dislikes=r.get("dislikes", 0),
            replies=[],
        )
        by_id[ro.id] = ro
        if ro.parent_id:
            children[ro.parent_id].append(ro)
    # Attach children
    for child_list in children.values():
        for child in child_list:
            parent = by_id.get(child.parent_id)
            if parent:
                parent.replies.append(child)
    # Return roots
    roots = [review for review in by_id.values() if review.parent_id is None]
    # sort by created_at (descending)
    roots.sort(key=lambda r: r.created_at, reverse=True)
    return roots


@router.get("/movies/{movie_id}/reviews", response_model=List[schemas.ReviewOut])
def list_reviews(movie_id: str, review_repo: ReviewRepository = Depends()) -> List[schemas.ReviewOut]:
    """List all reviews for a given movie ID, nested by replies."""
    reviews = review_repo.list_reviews_by_movie(movie_id)
    return build_review_tree(reviews)


@router.post("/movies/{movie_id}/reviews", response_model=schemas.ReviewOut, status_code=status.HTTP_201_CREATED)
def create_review_for_movie(
    movie_id: str,
    review: schemas.ReviewCreate,
    current_user: schemas.UserOut = Depends(get_current_user),
    review_repo: ReviewRepository = Depends(),
    movie_repo: MovieRepository = Depends(),
) -> schemas.ReviewOut:
    """Create a new review for the specified movie."""
    # Ensure movie exists
    if not movie_repo.get_movie(movie_id):
        raise HTTPException(status_code=404, detail="Movie not found")
    # Only allow one top-level review per user per movie (simplified rule)
    existing = [r for r in review_repo.list_reviews_by_movie(movie_id) if r["user_id"] == current_user.id and r.get("parent_id") is None]
    if existing:
        raise HTTPException(status_code=400, detail="You have already reviewed this movie")
    new_review = review_repo.create_review(current_user.id, current_user.username, review)
    return schemas.ReviewOut(
        id=new_review["id"],
        movie_id=new_review["movie_id"],
        user_id=new_review["user_id"],
        username=new_review["username"],
        rating=new_review["rating"],
        content=new_review["content"],
        parent_id=new_review.get("parent_id"),
        created_at=new_review.get("created_at"),
        likes=new_review.get("likes", 0),
        dislikes=new_review.get("dislikes", 0),
        replies=[],
    )


@router.put("/reviews/{review_id}", response_model=schemas.ReviewOut)
def update_review(
    review_id: str,
    update: dict,
    current_user: schemas.UserOut = Depends(get_current_user),
    review_repo: ReviewRepository = Depends(),
) -> schemas.ReviewOut:
    """Update an existing review (only by its owner)."""
    review = review_repo.get_review(review_id)
    if not review:
        raise HTTPException(status_code=404, detail="Review not found")
    if review["user_id"] != current_user.id:
        raise HTTPException(status_code=403, detail="You can only update your own reviews")
    updated = review_repo.update_review(review_id, content=update.get("content"), rating=update.get("rating"))
    return schemas.ReviewOut(
        id=updated["id"],
        movie_id=updated["movie_id"],
        user_id=updated["user_id"],
        username=updated["username"],
        rating=updated["rating"],
        content=updated["content"],
        parent_id=updated.get("parent_id"),
        created_at=updated.get("created_at"),
        likes=updated.get("likes", 0),
        dislikes=updated.get("dislikes", 0),
        replies=[],
    )


@router.delete("/reviews/{review_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_review(
    review_id: str,
    current_user: schemas.UserOut = Depends(get_current_user),
    review_repo: ReviewRepository = Depends(),
    user_repo: None = Depends(),  # unused but ensures DI loads user_repo
) -> None:
    """Delete a review (owner or admin)."""
    review = review_repo.get_review(review_id)
    if not review:
        raise HTTPException(status_code=404, detail="Review not found")
    # allow admin or owner
    if review["user_id"] != current_user.id and current_user.role != "admin":
        raise HTTPException(status_code=403, detail="You can only delete your own reviews")
    if not review_repo.delete_review(review_id):
        raise HTTPException(status_code=500, detail="Failed to delete review")


@router.post("/reviews/{review_id}/like", response_model=schemas.ReviewOut)
def like_review(
    review_id: str,
    current_user: schemas.UserOut = Depends(get_current_user),
    review_repo: ReviewRepository = Depends(),
) -> schemas.ReviewOut:
    """Like a review."""
    updated = review_repo.like_review(review_id)
    if not updated:
        raise HTTPException(status_code=404, detail="Review not found")
    return schemas.ReviewOut(
        id=updated["id"],
        movie_id=updated["movie_id"],
        user_id=updated["user_id"],
        username=updated["username"],
        rating=updated["rating"],
        content=updated["content"],
        parent_id=updated.get("parent_id"),
        created_at=updated.get("created_at"),
        likes=updated.get("likes", 0),
        dislikes=updated.get("dislikes", 0),
        replies=[],
    )


@router.post("/reviews/{review_id}/dislike", response_model=schemas.ReviewOut)
def dislike_review(
    review_id: str,
    current_user: schemas.UserOut = Depends(get_current_user),
    review_repo: ReviewRepository = Depends(),
) -> schemas.ReviewOut:
    """Dislike a review."""
    updated = review_repo.dislike_review(review_id)
    if not updated:
        raise HTTPException(status_code=404, detail="Review not found")
    return schemas.ReviewOut(
        id=updated["id"],
        movie_id=updated["movie_id"],
        user_id=updated["user_id"],
        username=updated["username"],
        rating=updated["rating"],
        content=updated["content"],
        parent_id=updated.get("parent_id"),
        created_at=updated.get("created_at"),
        likes=updated.get("likes", 0),
        dislikes=updated.get("dislikes", 0),
        replies=[],
    )