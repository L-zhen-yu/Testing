"""
Repository for review data stored in a JSON file.

Reviews are stored as dictionaries with fields defined in the ReviewOut schema.
This repository provides basic CRUD operations and some helper methods for
liking/disliking reviews and getting reviews by movie or user.
"""

import uuid
from datetime import datetime
from typing import List, Optional

from ..schemas import ReviewCreate, ReviewOut
from .base import JSONRepository


class ReviewRepository(JSONRepository):
    file_name = "reviews.json"

    def list_reviews(self) -> List[dict]:
        return self._read()

    def get_review(self, review_id: str) -> Optional[dict]:
        return self.find_by_id(review_id)

    def create_review(self, user_id: str, username: str, review: ReviewCreate) -> dict:
        reviews = self._read()
        new_review = {
            "id": str(uuid.uuid4()),
            "movie_id": review.movie_id,
            "user_id": user_id,
            "username": username,
            "rating": review.rating,
            "content": review.content,
            "parent_id": review.parent_id,
            "created_at": datetime.utcnow().isoformat(),
            "likes": 0,
            "dislikes": 0,
        }
        reviews.append(new_review)
        self._write(reviews)
        return new_review

    def update_review(self, review_id: str, content: Optional[str] = None, rating: Optional[int] = None) -> Optional[dict]:
        reviews = self._read()
        for r in reviews:
            if r["id"] == review_id:
                if content is not None:
                    r["content"] = content
                if rating is not None:
                    r["rating"] = rating
                self._write(reviews)
                return r
        return None

    def delete_review(self, review_id: str) -> bool:
        return self.delete_by_id(review_id)

    def list_reviews_by_movie(self, movie_id: str) -> List[dict]:
        return [r for r in self._read() if r["movie_id"] == movie_id]

    def list_reviews_by_user(self, user_id: str) -> List[dict]:
        return [r for r in self._read() if r["user_id"] == user_id]

    def like_review(self, review_id: str) -> Optional[dict]:
        reviews = self._read()
        for r in reviews:
            if r["id"] == review_id:
                r["likes"] = r.get("likes", 0) + 1
                self._write(reviews)
                return r
        return None

    def dislike_review(self, review_id: str) -> Optional[dict]:
        reviews = self._read()
        for r in reviews:
            if r["id"] == review_id:
                r["dislikes"] = r.get("dislikes", 0) + 1
                self._write(reviews)
                return r
        return None