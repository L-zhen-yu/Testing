"""
Repository for user data stored in a JSON file.

Users are stored as dictionaries with at least the following keys:
``id``, ``username``, ``password_hash``, ``full_name``, ``role``,
``penalties`` (list of strings), and ``favorites`` (list of movie IDs).
"""

import uuid
from typing import List, Optional

from ..auth import get_password_hash, verify_password
from ..schemas import UserCreate, UserOut
from .base import JSONRepository


class UserRepository(JSONRepository):
    file_name = "users.json"

    def get_user_by_username(self, username: str) -> Optional[UserOut]:
        users = self._read()
        for u in users:
            if u["username"] == username:
                return UserOut(
                    id=u["id"],
                    username=u["username"],
                    full_name=u.get("full_name", ""),
                    role=u.get("role", "user"),
                    penalties=u.get("penalties", []),
                    favorites=u.get("favorites", []),
                )
        return None

    def get_user_by_id(self, user_id: str) -> Optional[UserOut]:
        users = self._read()
        for u in users:
            if u["id"] == user_id:
                return UserOut(
                    id=u["id"],
                    username=u["username"],
                    full_name=u.get("full_name", ""),
                    role=u.get("role", "user"),
                    penalties=u.get("penalties", []),
                    favorites=u.get("favorites", []),
                )
        return None

    def create_user(self, user: UserCreate, role: str = "user") -> UserOut:
        users = self._read()
        # Ensure username not taken
        if any(u["username"] == user.username for u in users):
            raise ValueError("Username already exists")
        new_user = {
            "id": str(uuid.uuid4()),
            "username": user.username,
            "password_hash": get_password_hash(user.password),
            "full_name": user.full_name,
            "role": role,
            "penalties": [],
            "favorites": [],
        }
        users.append(new_user)
        self._write(users)
        return UserOut(
            id=new_user["id"],
            username=new_user["username"],
            full_name=new_user["full_name"],
            role=new_user["role"],
            penalties=[],
            favorites=[],
        )

    def authenticate_user(self, username: str, password: str) -> Optional[UserOut]:
        users = self._read()
        for u in users:
            if u["username"] == username and verify_password(password, u["password_hash"]):
                return UserOut(
                    id=u["id"],
                    username=u["username"],
                    full_name=u.get("full_name", ""),
                    role=u.get("role", "user"),
                    penalties=u.get("penalties", []),
                    favorites=u.get("favorites", []),
                )
        return None

    def list_users(self) -> List[UserOut]:
        users = self._read()
        return [
            UserOut(
                id=u["id"],
                username=u["username"],
                full_name=u.get("full_name", ""),
                role=u.get("role", "user"),
                penalties=u.get("penalties", []),
                favorites=u.get("favorites", []),
            )
            for u in users
        ]

    def add_favorite(self, user_id: str, movie_id: str) -> None:
        users = self._read()
        for u in users:
            if u["id"] == user_id:
                if movie_id not in u.get("favorites", []):
                    u.setdefault("favorites", []).append(movie_id)
                break
        self._write(users)

    def remove_favorite(self, user_id: str, movie_id: str) -> None:
        users = self._read()
        for u in users:
            if u["id"] == user_id:
                u.setdefault("favorites", [])
                if movie_id in u["favorites"]:
                    u["favorites"].remove(movie_id)
                break
        self._write(users)

    def add_penalty(self, user_id: str, reason: str) -> None:
        users = self._read()
        for u in users:
            if u["id"] == user_id:
                u.setdefault("penalties", []).append(reason)
                break
        self._write(users)