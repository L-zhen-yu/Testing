# Scrum Documents

This directory is intended to hold Scrum meeting notes and documents.  Examples include:

* Sprint planning agendas and summaries
* Stand‑up notes
* Sprint review and retrospective notes
* Task breakdowns and assignments

Please document your Scrum activities here as part of your development process.