"""
Authentication routes for the Movie Reviews API.

Exposes endpoints for user registration and obtaining access tokens
for login using the OAuth2 password flow.  Passwords are hashed
before being stored, and JWT tokens are returned for authenticated
sessions.
"""

from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm

from .. import schemas
from ..auth import create_access_token
from ..repositories.user_repository import UserRepository


router = APIRouter()


@router.post("/register", response_model=schemas.UserOut, status_code=status.HTTP_201_CREATED)
def register(user: schemas.UserCreate, user_repo: UserRepository = Depends()) -> schemas.UserOut:
    """Register a new user."""
    try:
        return user_repo.create_user(user, role="user")
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/token", response_model=schemas.Token)
def login(form_data: OAuth2PasswordRequestForm = Depends(), user_repo: UserRepository = Depends()) -> schemas.Token:
    """Authenticate user and return a JWT access token."""
    user = user_repo.authenticate_user(form_data.username, form_data.password)
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Incorrect username or password")
    access_token = create_access_token(data={"sub": user.username})
    return schemas.Token(access_token=access_token)